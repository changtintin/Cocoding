<!-- jQuery -->
<script src="../admin/js/jquery.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="../admin/js/bootstrap.min.js"></script>


<!-- <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script> -->
<script src ="../admin/js/summernote.min.js"></script>
<script src="../admin/js/scripts.js"></script>

</body>

</html>